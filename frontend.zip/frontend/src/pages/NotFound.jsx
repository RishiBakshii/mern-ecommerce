import React from 'react'

function NotFound() {
  return (
    <div
    className='text-[50px] items-center text-center'
    >NotFound</div>
  )
}

export default NotFound